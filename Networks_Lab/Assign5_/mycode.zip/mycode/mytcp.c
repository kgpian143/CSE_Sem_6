#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include "mytcp.h"
#define MAX_QUEUE_SIZE 10

typedef struct
{
    char *items[MAX_QUEUE_SIZE];
    int front;
    int rear;
} Queue;

Queue *createQueue()
{
    Queue *queue = (Queue *)malloc(sizeof(Queue));
    queue->front = 0;
    queue->rear = -1;
    return queue;
}

void destroyQueue(Queue *queue)
{
    free(queue);
}

int isEmpty(Queue *queue)
{
    return (queue->rear < queue->front);
}

int isFull(Queue *queue)
{
    return (queue->rear == MAX_QUEUE_SIZE - 1);
}

void enqueue(Queue *queue, char *item)
{
    if (isFull(queue))
    {
        printf("Error: Queue is full\n");
        exit(1);
    }
    queue->rear++;
    queue->items[queue->rear] = (char *)malloc(strlen(item) + 1);
    strcpy(queue->items[queue->rear], item);
}

char *dequeue(Queue *queue)
{
    if (isEmpty(queue))
    {
        printf("Error: Queue is empty\n");
        exit(1);
    }
    char *item = queue->items[queue->front];
    queue->front++;
    return item;
}

Queue *Send_Message, *Received_Message;

pthread_t R, S;

void *func_R(void *arg)
{
    while (1)
    {
        int sockfd = (int)arg;
        char buf[1000];
        char message[5005];
        while (1)
        {
            int n = recv(sockfd, buf, 1000, 0);
            if (n == 0)
                break;
            strcat(message, buf);
            for (int i = 0; i < 1000; i++)
                buf[i] = '\0';
        }

        while (isFull(Received_Message))
            sleep(5);
        enqueue(Received_Message, message);
    }
    pthread_exit(NULL);
}

void *func_S(void *arg)
{
    while (1)
    {
        int sockfd = (int)arg;
        char buf[1000];
        char message[5005];
        while (isEmpty(Send_Message) != 1)
        {
            strcpy(message, dequeue(Send_Message));
            int j = 0;
            for (int i = 0; i < 5000; i++)
            {
                if (j == 999)
                {
                    send(sockfd, buf, 1000, 0);
                    for (int k = 0; k < 1000; k++)
                        buf[k] = '\0';
                }
                buf[j++] = message[i];
            }
            send(sockfd, buf, 1000, 0);
            for (int k = 0; k < 1000; k++)
                buf[k] = '\0';
            send(sockfd, buf, strlen(buf), 0);
        }
        sleep(5);
    }
    pthread_exit(NULL);
}
int my_socket(int family, int type, int protocol)
{
    int fd = socket(family, SOCK_STREAM, protocol);
    pthread_create(&R, NULL, func_R, (void *)fd);
    pthread_create(&S, NULL, func_S, (void *)fd);
    Send_Message = createQueue();
    Received_Message = createQueue();
    return fd;
}

int my_bind(int Sockfd, struct sockaddr *addr, socklen_t addrlen)
{
    return bind(Sockfd, addr,
                addrlen);
}

int my_listen(int Sockfd, int clients)
{
    return listen(Sockfd, clients);
}

int my_accept(int Sockfd, struct sockaddr *addr, socklen_t addrlen)
{
    return connect(Sockfd, addr, addrlen);
}

ssize_t my_send(int Sockfd, const char *buf, size_t len, int flags)
{
    while (1)
    {
        if (isFull(Send_Message))
            sleep(5);
        else
        {
            enqueue(Send_Message, buf);
            break;
        }
    }
    return strlen(buf);
}

ssize_t my_recv(int Sockfd, const char *buf, size_t len, int flags)
{
    while (1)
    {
        if (isEmpty(Received_Message))
            sleep(5);
        else
        {
            strcpy(buf, dequeue(Received_Message));
            break;
        }
    }

    return strlen(buf);
}

int my_close(int Sockfd)
{
    pthread_cancel(R);
    pthread_cancel(S);
    destroyQueue(Send_Message);
    destroyQueue(Received_Message);
    close(Sockfd);
}
int main(int argc, char *argv[])
{
}